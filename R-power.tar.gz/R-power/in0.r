# Cargar el CSV
n<-read.csv(file="nums.csv",head=TRUE,sep=";")
# mostrar datos leidos
n
# mostrar resumen de datos leidos
summary(n)
 
